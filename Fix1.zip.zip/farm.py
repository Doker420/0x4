# farm.py — версия 5.1
# ФИКС: bridge работает в главном процессе (как в bot.py),
# multiprocessing убран — он ломал Playwright/cookies.
#
# Что делает:
#  - Инициализирует DeepSeek bridge так же, как bot.py
#  - Грузит донор (data/donor/messages.json + медиа)
#  - Запускает N юзерботов (Pyrogram)
#  - Генерирует реплики по персоне + примерам из донора
#  - Клонирует фрагменты диалогов донора
#  - Раз в N сообщений играет Q→A связку
#  - Переиспользует медиа донора (стикеры/гиф/фото)
#  - Голосовые отправляет как НАСТОЯЩИЕ voice (send_voice, .ogg Opus)
#  - Ставит реакции
#  - Watchdog: пингует bridge раз в 5 мин и пересоздаёт клиент при смерти

from __future__ import annotations

import argparse
import asyncio
import atexit
import json
import logging
import os
import random
import signal
import socket
import sys
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any

import aiofiles
from dotenv import load_dotenv

try:
    from pyrogram import Client
    from pyrogram.enums import ChatAction
    from pyrogram.errors import RPCError
    from pyrogram.types import Message as TGMessage
except ImportError as exc:
    raise SystemExit("Установите: pip install pyrogram tgcrypto") from exc

ROOT = Path(__file__).resolve().parent
BRIDGE_DIR = ROOT / "vendor" / "Deepseek-API"
if BRIDGE_DIR.exists():
    sys.path.insert(0, str(BRIDGE_DIR))

try:
    from deepseek import DeepSeekClient
except ImportError as exc:
    raise SystemExit(
        "Не найден DeepSeek bridge. Проверьте vendor/Deepseek-API."
    ) from exc

load_dotenv(ROOT / ".env")

DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)
SESSIONS_DIR = ROOT / "sessions"
SESSIONS_DIR.mkdir(exist_ok=True)
DONOR_DIR = DATA_DIR / "donor"
DONOR_MESSAGES = DONOR_DIR / "messages.json"

STATE_FILE = DATA_DIR / "farm_state.json"
STATS_FILE = DATA_DIR / "farm_stats.json"
LOCK_FILE = DATA_DIR / "farm.lock"

DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "default")
DEEPSEEK_THINKING = os.getenv("DEEPSEEK_THINKING", "false").lower() == "true"
DEEPSEEK_SEARCH = os.getenv("DEEPSEEK_SEARCH", "false").lower() == "true"

log = logging.getLogger("farm")


# ═══════════════════════════════════════════════════════════════
#                     LOCK FILE
# ═══════════════════════════════════════════════════════════════

def acquire_lock() -> None:
    if LOCK_FILE.exists():
        try:
            old_pid = int(LOCK_FILE.read_text().strip())
            if old_pid != os.getpid():
                os.kill(old_pid, 0)
                raise SystemExit(f"Ферма уже запущена (PID {old_pid})")
        except (ProcessLookupError, ValueError, OSError):
            LOCK_FILE.unlink(missing_ok=True)
    LOCK_FILE.write_text(str(os.getpid()))


def release_lock() -> None:
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except Exception:
        pass


atexit.register(release_lock)


# ═══════════════════════════════════════════════════════════════
#                TELEGRAM REACHABILITY (не висит)
# ═══════════════════════════════════════════════════════════════

TG_DC_HOSTS = [
    ("149.154.167.51", 443),
    ("149.154.175.53", 443),
    ("91.108.56.130", 443),
    ("149.154.171.5", 443),
    ("api.telegram.org", 443),
]


def _probe_tcp(host: str, port: int, timeout: float) -> tuple[bool, str]:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True, "ok"
    except socket.timeout:
        return False, f"timeout {timeout}s"
    except socket.gaierror as e:
        return False, f"DNS: {e}"
    except OSError as e:
        return False, f"OSError: {e}"
    finally:
        try:
            s.close()
        except Exception:
            pass


async def check_telegram_reachable(timeout: float = 5.0) -> tuple[bool, str]:
    lines = []
    for host, port in TG_DC_HOSTS:
        ok, msg = await asyncio.to_thread(_probe_tcp, host, port, timeout)
        lines.append(f"  {'✅' if ok else '❌'} {host}:{port} — {msg}")
        if ok:
            return True, "\n".join(lines)
    return False, "\n".join(lines)


# ═══════════════════════════════════════════════════════════════
#        DEEPSEEK BRIDGE — в ГЛАВНОМ процессе (как в bot.py)
# ═══════════════════════════════════════════════════════════════

class DeepSeekBridge:
    """
    Работает в ГЛАВНОМ процессе, тот же cwd/HOME/sys.path, что у бота.
    Использует asyncio.to_thread — точно так же, как bot.py.
    Потокобезопасен через asyncio.Lock.
    """

    def __init__(self) -> None:
        self._client: Any = None
        self._lock = asyncio.Lock()
        self._conversation_id: str | None = None
        self._ready = False
        self._last_ok = 0.0

    @property
    def is_ready(self) -> bool:
        return self._ready and self._client is not None

    async def start(self, verbose: bool = False) -> None:
        log.info("Инициализация DeepSeek bridge (главный процесс)...")
        t = time.time()
        try:
            self._client = await asyncio.to_thread(DeepSeekClient, None, False)
        except Exception as e:
            log.exception("DeepSeek init failed")
            raise RuntimeError(f"DeepSeek init failed: {e}") from e
        log.info("✅ DeepSeek bridge готов за %.1fs", time.time() - t)
        self._ready = True
        self._last_ok = time.time()

    async def stop(self) -> None:
        if self._client is not None:
            try:
                await asyncio.to_thread(self._client.close)
            except Exception:
                log.exception("DeepSeek close err")
            self._client = None
            self._ready = False

    async def _recreate(self) -> None:
        log.warning("Пересоздаю DeepSeek-клиент...")
        stale = self._client
        try:
            self._client = await asyncio.to_thread(DeepSeekClient, None, False)
            self._conversation_id = None
            self._last_ok = time.time()
            log.info("DeepSeek-клиент пересоздан")
        finally:
            if stale is not None:
                try:
                    await asyncio.to_thread(stale.close)
                except Exception:
                    pass

    async def _ask_locked(self, prompt: str, new: bool) -> str:
        assert self._client is not None
        if new or not self._conversation_id:
            reply = await asyncio.to_thread(
                self._client.chat,
                prompt,
                model=DEEPSEEK_MODEL,
                thinking=DEEPSEEK_THINKING,
                search=DEEPSEEK_SEARCH,
            )
        else:
            reply = await asyncio.to_thread(
                self._client.chat,
                prompt,
                conversation_id=self._conversation_id,
                thinking=DEEPSEEK_THINKING,
                search=DEEPSEEK_SEARCH,
            )
        self._conversation_id = reply.conversation_id
        self._last_ok = time.time()
        return reply.text.strip()

    async def ask(self, prompt: str, new_conversation: bool = False) -> str:
        async with self._lock:
            if self._client is None:
                await self._recreate()
            try:
                return await self._ask_locked(prompt, new_conversation)
            except Exception:
                log.exception("DeepSeek fail → пересоздание клиента")
                await self._recreate()
                return await self._ask_locked(prompt, True)

    async def ping(self) -> bool:
        """Watchdog-проверка. Возвращает True, если bridge отвечает."""
        try:
            await self.ask("ping", new_conversation=False)
            return True
        except Exception:
            log.exception("Watchdog: ping failed")
            return False

    def seconds_since_last_ok(self) -> float:
        return time.time() - self._last_ok if self._last_ok else 9999.0


# ═══════════════════════════════════════════════════════════════
#                    STATE
# ═══════════════════════════════════════════════════════════════

class FarmState:
    def __init__(self) -> None:
        self.chat_history: deque[dict[str, Any]] = deque(maxlen=60)
        self.topic: str = "общее общение"
        self.lock = asyncio.Lock()

    def to_dict(self) -> dict[str, Any]:
        return {"chat_history": list(self.chat_history), "topic": self.topic}

    def load(self, data: dict[str, Any]) -> None:
        self.chat_history = deque(data.get("chat_history", []), maxlen=60)
        self.topic = data.get("topic", "общее общение")


async def load_json(path: Path, default: Any) -> Any:
    try:
        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            return json.loads(await f.read())
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


async def save_json(path: Path, value: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    async with aiofiles.open(tmp, "w", encoding="utf-8") as f:
        await f.write(json.dumps(value, ensure_ascii=False, indent=2))
    os.replace(tmp, path)


# ═══════════════════════════════════════════════════════════════
#                    DONOR CORPUS
# ═══════════════════════════════════════════════════════════════

class DonorCorpus:
    def __init__(self) -> None:
        self.messages: list[dict[str, Any]] = []
        self.texts: list[str] = []
        self.media_by_kind: dict[str, list[dict[str, Any]]] = {
            "sticker": [], "gif": [], "photo": [], "voice": [],
        }
        self.qa_pairs: list[tuple[dict, dict]] = []
        self.fragments: list[list[dict]] = []

    @classmethod
    async def load(cls, path: Path) -> "DonorCorpus":
        inst = cls()
        if not path.exists():
            log.warning("Донор %s не найден — работаю без него", path)
            return inst

        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            data = json.loads(await f.read())

        inst.messages = data

        for m in data:
            kind = m.get("kind", "text")
            text = (m.get("text") or "").strip()
            if kind == "text" and text:
                inst.texts.append(text)
            elif kind in inst.media_by_kind and m.get("media_file"):
                inst.media_by_kind[kind].append(m)

        for i in range(len(data) - 1):
            a, b = data[i], data[i + 1]
            a_txt = (a.get("text") or "").strip()
            b_txt = (b.get("text") or "").strip()
            if a_txt.endswith("?") and b_txt:
                inst.qa_pairs.append((a, b))

        if len(data) >= 3:
            i = 0
            while i < len(data):
                size = random.randint(3, 8)
                frag = data[i:i + size]
                if len(frag) >= 3:
                    inst.fragments.append(frag)
                i += size

        log.info(
            "Донор: %d сообщений | текстов: %d | Q→A: %d | фрагментов: %d | медиа: %s",
            len(inst.messages), len(inst.texts), len(inst.qa_pairs),
            len(inst.fragments),
            {k: len(v) for k, v in inst.media_by_kind.items()},
        )
        return inst

    def sample_texts(self, n: int = 8) -> list[str]:
        if not self.texts:
            return []
        return random.sample(self.texts, min(n, len(self.texts)))

    def sample_media(self, kind: str) -> dict[str, Any] | None:
        pool = self.media_by_kind.get(kind) or []
        return random.choice(pool) if pool else None

    def sample_fragment(self, min_size: int = 3, max_size: int = 8) -> list[dict]:
        pool = [f for f in self.fragments if min_size <= len(f) <= max_size]
        return random.choice(pool) if pool else []

    def sample_qa(self) -> tuple[dict, dict] | None:
        return random.choice(self.qa_pairs) if self.qa_pairs else None

    def pick_topic_seed(self) -> str:
        if not self.texts:
            return "общее общение"
        return random.choice(self.texts)[:120]


# ═══════════════════════════════════════════════════════════════
#                    PROMPTS
# ═══════════════════════════════════════════════════════════════

REPLY_PROMPT = """Ты — участник группового чата. Отвечай ТОЛЬКО одной короткой репликой (1–2 предложения, до 200 символов), без кавычек и пояснений.

Твоя роль: {persona}
Текущая тема: {topic}

Примеры живых сообщений из похожего чата (стиль, НЕ копируй):
{examples}

Последние сообщения в нашем чате:
{context}

Правила:
- разговорно, живо, можно эмодзи
- если уместно — задай короткий вопрос
- не упоминай, что ты ИИ
- отвечай на языке последних сообщений

Твоя реплика:"""

FRAGMENT_PROMPT = """Ты — переписываешь кусок диалога из другого чата в стиль участника "{persona}".

Оригинальный фрагмент:
{fragment}

Тема нового чата: {topic}

Перепиши ОДНУ следующую реплику за "{persona}" — коротко, живо, до 200 символов. Не копируй дословно, сохрани смысл и настрой. Только текст:"""

QA_QUESTION_PROMPT = """Ты — участник чата "{persona}". Задай ОДИН короткий живой вопрос (до 100 символов) по мотивам:

Оригинал: "{original}"

Не копируй дословно. Только текст вопроса:"""

QA_ANSWER_PROMPT = """Ты — участник чата "{persona}". Ответь ОДНОЙ короткой репликой (до 200 символов) на вопрос:

"{question}"

Тема чата: {topic}
Живо, разговорно, можно эмодзи. Только текст:"""

TOPIC_PROMPT = """Придумай ОДНУ новую тему для обсуждения (до 10 слов), близкую по духу к таким сообщениям:

{seeds}

Текущая тема: {topic}
Только текст темы:"""

REACTION_PROMPT = """Выбери ОДНУ реакцию-эмодзи для сообщения: "{text}"
Ответь только одним эмодзи из: 👍 ❤️ 🔥 😁 🤔 👏 🎉 😢 🤯
Эмодзи:"""


def build_context(history: deque[dict[str, Any]], limit: int = 12) -> str:
    items = list(history)[-limit:]
    lines = []
    for item in items:
        who = item.get("author", "anon")
        text = item.get("text") or f"[{item.get('kind', 'media')}]"
        lines.append(f"{who}: {text}")
    return "\n".join(lines) or "(пусто)"


async def generate_reply(bridge: Any, state: FarmState, donor: DonorCorpus, persona: str) -> str:
    if bridge and getattr(bridge, "is_ready", False):
        try:
            async with state.lock:
                context = build_context(state.chat_history)
                topic = state.topic
            examples = donor.sample_texts(8)
            examples_block = "\n".join(f"— {t}" for t in examples) or "(нет)"
            prompt = REPLY_PROMPT.format(persona=persona, topic=topic, examples=examples_block, context=context)
            text = await bridge.ask(prompt)
            if text:
                return text.strip().strip('"').strip("«»")[:280]
        except Exception as e:
            log.warning("[%s] DeepSeek error, fallback на донор: %s", persona[:20], e)

    sample = donor.sample_texts(1)
    return sample[0] if sample else "Интересная мысль 👍"


async def generate_from_fragment(bridge: Any, state: FarmState, donor: DonorCorpus, persona: str, fragment: Any) -> str:
    if bridge and getattr(bridge, "is_ready", False):
        try:
            lines = []
            for m in fragment:
                txt = (m.get("text") or "").strip() or f"[{m.get('kind')}]"
                lines.append(f"- {txt[:160]}")
            async with state.lock:
                topic = state.topic
            prompt = FRAGMENT_PROMPT.format(persona=persona, fragment="\n".join(lines), topic=topic)
            text = await bridge.ask(prompt)
            if text:
                return text.strip().strip('"').strip("«»")[:280]
        except Exception as e:
            log.warning("[%s] fragment gen error: %s", persona[:20], e)

    sample = donor.sample_texts(1)
    return sample[0] if sample else ""


async def generate_question(bridge: Any, persona: str, original: str) -> str:
    if bridge and getattr(bridge, "is_ready", False):
        try:
            prompt = QA_QUESTION_PROMPT.format(persona=persona, original=original[:200])
            text = await bridge.ask(prompt)
            if text:
                return text.strip().strip('"').strip("«»")[:200]
        except Exception as e:
            log.warning("Q gen error: %s", e)
    return original[:200] if original else "А что думаете по этому поводу?"


async def generate_answer(bridge: Any, state: FarmState, persona: str, question: str) -> str:
    if bridge and getattr(bridge, "is_ready", False):
        try:
            async with state.lock:
                topic = state.topic
            prompt = QA_ANSWER_PROMPT.format(persona=persona, question=question, topic=topic)
            text = await bridge.ask(prompt)
            if text:
                return text.strip().strip('"').strip("«»")[:280]
        except Exception as e:
            log.warning("A gen error: %s", e)
    return "Думаю, в этом определённо есть смысл."


async def generate_new_topic(bridge: Any, state: FarmState, donor: DonorCorpus) -> str:
    if bridge and getattr(bridge, "is_ready", False):
        try:
            async with state.lock:
                old = state.topic
            seeds = donor.sample_texts(10)
            seed_block = "\n".join(f"— {s}" for s in seeds) or "— (нет)"
            t = await bridge.ask(TOPIC_PROMPT.format(seeds=seed_block, topic=old))
            if t:
                return t.strip().strip('"').strip("«»")[:80] or "общее общение"
        except Exception:
            pass
    return "новости и обсуждения"


async def generate_reaction(bridge: Any, text: str) -> str:
    allowed = ["👍", "❤️", "🔥", "😁", "🤔", "👏", "🎉", "😢", "🤯"]
    if bridge and getattr(bridge, "is_ready", False):
        try:
            emoji = (await bridge.ask(REACTION_PROMPT.format(text=text[:200]))).strip()
            for a in allowed:
                if a in emoji:
                    return a
        except Exception:
            pass
    return random.choice(["👍", "🔥", "❤️", "👏", "😁"])
    return random.choice(allowed)


# ═══════════════════════════════════════════════════════════════
#                    FARM ACCOUNT
# ═══════════════════════════════════════════════════════════════

class FarmAccount:
    def __init__(self, cfg, bridge, state, donor, farm_accounts_ref):
        self.cfg = cfg
        self.name: str = cfg["name"]
        self.persona: str = cfg.get("persona", "обычный участник чата")
        self.reply_probability: float = float(cfg.get("reply_probability", 0.8))
        self.media_bias: dict[str, float] = cfg.get(
            "media_bias",
            {"text": 0.6, "sticker": 0.2, "gif": 0.1, "photo": 0.05, "voice": 0.05},
        )
        self.bridge = bridge
        self.state = state
        self.donor = donor
        self.farm_accounts = farm_accounts_ref

        session_string = os.getenv(f"SESSION_{self.name.upper()}")
        client_kwargs: dict[str, Any] = {
            "name": self.name,
            "api_id": int(cfg["api_id"]),
            "api_hash": str(cfg["api_hash"]),
            "workdir": str(SESSIONS_DIR),
        }
        if session_string:
            client_kwargs["session_string"] = session_string
        else:
            client_kwargs["phone_number"] = cfg.get("phone")
        proxy = cfg.get("proxy") or FARM_CFG.get("proxy")
        if proxy:
            client_kwargs["proxy"] = proxy

        self.client = Client(**client_kwargs)
        self._running = False
        self._task: asyncio.Task | None = None

    async def start(self, timeout: float = 90.0) -> None:
        log.info("[%s] start()", self.name)
        try:
            await asyncio.wait_for(self.client.start(), timeout=timeout)
        except asyncio.TimeoutError:
            raise RuntimeError(f"[{self.name}] start timeout")
        me = await self.client.get_me()
        log.info("Аккаунт %s вошёл как @%s (id=%s)", self.name, me.username, me.id)
        # Priming peer cache — required for supergroup IDs (-100...) in Pyrogram 2.0
        target = FARM_CFG.get("target_chat_id")
        if target:
            try:
                await self.client.get_chat(int(target))
                log.info("[%s] peer %s resolved OK", self.name, target)
            except Exception as e:
                log.warning("[%s] peer pre-resolve failed (non-fatal): %s", self.name, e)
        self._running = True
        self._task = asyncio.create_task(self._loop(), name=f"farm-{self.name}")

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            except Exception:
                log.exception("task stop %s", self.name)
        try:
            await asyncio.wait_for(self.client.stop(), timeout=15.0)
        except Exception:
            log.exception("client.stop %s", self.name)

    async def _loop(self) -> None:
        farm_cfg = FARM_CFG.get("farm", {})
        min_d = farm_cfg.get("min_delay_sec", 5)
        max_d = farm_cfg.get("max_delay_sec", 45)
        while self._running:
            try:
                await asyncio.sleep(random.uniform(min_d, max_d))
                if not self._running:
                    break
                if random.random() > self.reply_probability:
                    continue
                await self._act()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("loop err %s", self.name)
                await asyncio.sleep(20)

    async def _act(self) -> None:
        farm_cfg = FARM_CFG.get("farm", {})
        roll = random.random()
        if roll < farm_cfg.get("qa_probability", 0.35) and len(self.farm_accounts) >= 2:
            await self._do_qa()
            return
        if roll < farm_cfg.get("qa_probability", 0.35) + farm_cfg.get("clone_probability", 0.45):
            if await self._send_from_fragment():
                return
        await self._send_reply()

    async def _do_qa(self) -> None:
        qa = self.donor.sample_qa()
        if not qa:
            return
        orig_q, _ = qa
        orig_q_text = (orig_q.get("text") or "").strip()
        if not orig_q_text:
            return
        others = [a for a in self.farm_accounts if a is not self]
        if not others:
            return
        other = random.choice(others)
        try:
            question = await generate_question(self.bridge, self.persona, orig_q_text)
        except Exception:
            log.exception("Q gen failed")
            return
        if not question:
            return
        await self._send_text(question)
        delay = random.uniform(3, 15)
        log.info("[%s→%s] Q, ответ через %.1fs", self.name, other.name, delay)
        await asyncio.sleep(delay)
        try:
            answer = await generate_answer(other.bridge, other.state, other.persona, question)
        except Exception:
            log.exception("A gen failed")
            return
        if answer:
            await other._send_text(answer)

    async def _send_from_fragment(self) -> bool:
        frag = self.donor.sample_fragment()
        if not frag:
            return False
        try:
            text = await generate_from_fragment(self.bridge, self.state, self.donor, self.persona, frag)
        except Exception:
            log.exception("fragment gen failed")
            return False
        if not text:
            return False
        await self._send_text(text)
        return True

    async def _send_reply(self) -> None:
        try:
            text = await generate_reply(self.bridge, self.state, self.donor, self.persona)
        except Exception:
            log.exception("[%s] reply gen fail", self.name)
            return
        kind = self._pick_kind()
        try:
            if kind == "text":
                await self._send_text(text)
            elif kind == "sticker":
                await self._send_sticker()
            elif kind == "gif":
                await self._send_gif()
            elif kind == "photo":
                await self._send_photo()
            elif kind == "voice":
                await self._send_voice()
        except Exception:
            log.exception("send %s", self.name)

    def _pick_kind(self) -> str:
        if random.random() < 0.7:
            return "text"
        keys = list(self.media_bias.keys())
        weights = [self.media_bias[k] for k in keys]
        return random.choices(keys, weights=weights, k=1)[0]

    async def _typing(self, seconds: float) -> None:
        if not FARM_CFG.get("farm", {}).get("typing_simulation", True):
            return
        try:
            await self.client.send_chat_action(FARM_CFG["target_chat_id"], ChatAction.TYPING)
            await asyncio.sleep(seconds)
        except Exception:
            pass

    async def _send_text(self, text: str, reply_to: dict | None = None) -> None:
        if not text:
            return
        chat_id = FARM_CFG["target_chat_id"]
        topic_id = FARM_CFG.get("topic_id")
        reply_id = ((reply_to or {}).get("message_id") if reply_to else None) or topic_id
        try:
            await self._typing(min(len(text) / 20, 3))
            kwargs: dict[str, Any] = {"chat_id": chat_id, "text": text}
            if reply_id:
                kwargs["reply_to_message_id"] = reply_id
            msg = await self.client.send_message(**kwargs)
            await self._record(msg, text, "text")
            log.info("[%s] → %s", self.name, text[:80])
        except Exception:
            log.exception("send_text failed")

    async def _send_sticker(self) -> None:
        d = self.donor.sample_media("sticker")
        chat_id = FARM_CFG["target_chat_id"]
        topic_id = FARM_CFG.get("topic_id")
        kwargs: dict[str, Any] = {"chat_id": chat_id}
        if topic_id:
            kwargs["reply_to_message_id"] = topic_id
        try:
            if d and d.get("media_file"):
                path = ROOT / d["media_file"]
                if path.exists():
                    msg = await self.client.send_sticker(sticker=str(path), **kwargs)
                    await self._record(msg, "", "sticker")
                    log.info("[%s] sticker (donor)", self.name)
                    return
            stickers = FARM_CFG.get("stickers") or []
            if stickers:
                msg = await self.client.send_sticker(sticker=random.choice(stickers), **kwargs)
                await self._record(msg, "", "sticker")
        except Exception:
            log.exception("sticker failed")

    async def _send_gif(self) -> None:
        d = self.donor.sample_media("gif")
        chat_id = FARM_CFG["target_chat_id"]
        topic_id = FARM_CFG.get("topic_id")
        kwargs: dict[str, Any] = {"chat_id": chat_id}
        if topic_id:
            kwargs["reply_to_message_id"] = topic_id
        try:
            if d and d.get("media_file"):
                path = ROOT / d["media_file"]
                if path.exists():
                    msg = await self.client.send_animation(animation=str(path), **kwargs)
                    await self._record(msg, "", "gif")
                    log.info("[%s] gif (donor)", self.name)
                    return
            gifs = FARM_CFG.get("gifs") or []
            if gifs:
                msg = await self.client.send_animation(animation=random.choice(gifs), **kwargs)
                await self._record(msg, "", "gif")
        except Exception:
            log.exception("gif failed")

    async def _send_photo(self) -> None:
        d = self.donor.sample_media("photo")
        chat_id = FARM_CFG["target_chat_id"]
        topic_id = FARM_CFG.get("topic_id")
        kwargs: dict[str, Any] = {"chat_id": chat_id}
        if topic_id:
            kwargs["reply_to_message_id"] = topic_id
        try:
            if d and d.get("media_file"):
                path = ROOT / d["media_file"]
                if path.exists():
                    msg = await self.client.send_photo(photo=str(path), **kwargs)
                    await self._record(msg, "", "photo")
                    log.info("[%s] photo (donor)", self.name)
                    return
            photos = FARM_CFG.get("photos") or []
            if photos:
                msg = await self.client.send_photo(photo=random.choice(photos), **kwargs)
                await self._record(msg, "", "photo")
        except Exception:
            log.exception("photo failed")

    async def _send_voice(self) -> None:
        """
        Голосовое — как НАСТОЯЩИЙ voice-note.
        send_voice() → отправит как voice. Файл должен быть .ogg (Opus).
        Из донора у нас .ogg — как раз то, что нужно.
        """
        d = self.donor.sample_media("voice")
        chat_id = FARM_CFG["target_chat_id"]
        topic_id = FARM_CFG.get("topic_id")
        if not (d and d.get("media_file")):
            return
        path = ROOT / d["media_file"]
        if not path.exists():
            return
        kwargs: dict[str, Any] = {"chat_id": chat_id, "voice": str(path)}
        if topic_id:
            kwargs["reply_to_message_id"] = topic_id
        try:
            await self._typing(2)
            msg = await self.client.send_voice(**kwargs)
            await self._record(msg, "", "voice")
            log.info("[%s] voice (donor, %s)", self.name, path.name)
        except Exception:
            log.exception("voice failed")

    async def _send_reaction_to_last(self) -> None:
        async with self.state.lock:
            if not self.state.chat_history:
                return
            last = self.state.chat_history[-1]
        if last.get("kind") != "text" or not last.get("text"):
            return
        if random.random() > FARM_CFG.get("farm", {}).get("reaction_probability", 0.35):
            return
        try:
            emoji = await generate_reaction(self.bridge, last["text"])
        except Exception:
            return
        try:
            await self.client.send_reaction(
                chat_id=FARM_CFG["target_chat_id"],
                message_id=last["message_id"],
                emoji=emoji,
            )
            log.info("[%s] реакция %s на msg %s", self.name, emoji, last["message_id"])
        except RPCError as e:
            log.warning("[%s] реакция fail: %s", self.name, e)
        except Exception:
            log.exception("reaction failed")

    async def _record(self, msg: TGMessage, text: str, kind: str) -> None:
        async with self.state.lock:
            self.state.chat_history.append({
                "author": self.name,
                "user_id": msg.from_user.id if msg.from_user else 0,
                "message_id": msg.id,
                "text": text,
                "kind": kind,
                "ts": datetime.now().isoformat(timespec="seconds"),
            })


# ═══════════════════════════════════════════════════════════════
#                    ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════

FARM_CFG: dict[str, Any] = {}
FARM_STATS: dict[str, Any] = {"started_at": None, "sent": 0}


async def run_farm() -> None:
    global FARM_CFG

    cfg_path = ROOT / "farm_config.json"
    if not cfg_path.exists():
        raise SystemExit(f"Нет конфига: {cfg_path}")
    async with aiofiles.open(cfg_path, "r", encoding="utf-8") as f:
        FARM_CFG = json.loads(await f.read())

    override_target = os.getenv("FARM_OVERRIDE_TARGET")
    if override_target and int(override_target) != 0:
        FARM_CFG["target_chat_id"] = int(override_target)

    farm_sub = FARM_CFG.setdefault("farm", {})
    override_min = os.getenv("FARM_OVERRIDE_MIN_DELAY")
    if override_min:
        farm_sub["min_delay_sec"] = float(override_min)
    override_max = os.getenv("FARM_OVERRIDE_MAX_DELAY")
    if override_max:
        farm_sub["max_delay_sec"] = float(override_max)

    if not FARM_CFG.get("target_chat_id"):
        raise SystemExit("target_chat_id не задан")
    accounts_cfg = FARM_CFG.get("accounts") or []
    if not accounts_cfg:
        raise SystemExit("Нет accounts в конфиге")

    log.info("Подключаю %d аккаунтов...", len(accounts_cfg))

    # 1) Telegram
    log.info("→ Проверка TCP-связи с Telegram DC")
    ok, report = await check_telegram_reachable(timeout=3.0)
    for line in report.splitlines():
        log.info(line)
    if not ok:
        log.warning("⚠️ Прямой TCP-пинг Telegram DC не ответил (возможно, нужен прокси или фаервол блокирует порты). Пробуем прямое подключение клиентов...")
    else:
        log.info("✅ Telegram DC доступен")

    # 2) Донор
    log.info("→ Загрузка донора")
    donor = await DonorCorpus.load(DONOR_MESSAGES)

    # 3) State
    log.info("→ Загрузка состояния")
    state = FarmState()
    saved = await load_json(STATE_FILE, {})
    if saved:
        state.load(saved)
        log.info("   тема=%r, история=%d", state.topic, len(state.chat_history))

    # 4) Bridge — в ГЛАВНОМ процессе
    log.info("→ Инициализация DeepSeek bridge")
    bridge = DeepSeekBridge()
    try:
        await bridge.start()
        log.info("✅ DeepSeek готов")
    except Exception as e:
        log.warning("⚠️ DeepSeek bridge не поднялся: %s", e)
        log.warning("ℹ️ Ферма запускается в автономном режиме (на базе базы донора и шаблонов)!")
        bridge = None

    # 5) Аккаунты
    accounts: list[FarmAccount] = []
    stop_event = asyncio.Event()

    def _on_signal(*_: Any) -> None:
        log.info("Сигнал остановки")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            signal.signal(sig, lambda *_: stop_event.set())

    try:
        for acc_cfg in accounts_cfg:
            name = acc_cfg.get("name", "?")
            log.info("→ Запускаю аккаунт %s", name)
            acc = FarmAccount(acc_cfg, bridge, state, donor, accounts)
            try:
                await acc.start(timeout=90.0)
                accounts.append(acc)
                log.info("   ✅ %s", name)
            except Exception as e:
                log.error("   ❌ %s: %s", name, e)

        if not accounts:
            raise SystemExit("Ни один аккаунт не запустился")

        for a in accounts:
            a.farm_accounts = accounts

        FARM_STATS["started_at"] = datetime.now().isoformat(timespec="seconds")
        log.info("🎉 Ферма запущена: %d аккаунтов. Ctrl+C — стоп.", len(accounts))

        # Autosave
        async def autosave() -> None:
            while True:
                await asyncio.sleep(30)
                try:
                    await save_json(STATE_FILE, state.to_dict())
                    await save_json(STATS_FILE, FARM_STATS)
                except Exception:
                    log.exception("autosave failed")

        # Watchdog для bridge
        async def bridge_watchdog() -> None:
            while True:
                await asyncio.sleep(300)  # раз в 5 минут
                try:
                    if bridge.seconds_since_last_ok() > 600:
                        log.warning("Bridge молчит >10 мин → ping")
                        ok = await bridge.ping()
                        if not ok:
                            log.warning("Bridge не отвечает → пересоздание")
                            await bridge._recreate()
                except asyncio.CancelledError:
                    break
                except Exception:
                    log.exception("watchdog err")

        # Реакции
        async def reaction_worker() -> None:
            while True:
                try:
                    await asyncio.sleep(random.uniform(60, 120))
                    if accounts:
                        acc = random.choice(accounts)
                        await acc._send_reaction_to_last()
                except asyncio.CancelledError:
                    break
                except Exception:
                    log.exception("reaction_worker err")

        saver = asyncio.create_task(autosave(), name="farm-autosave")
        watchdog = asyncio.create_task(bridge_watchdog(), name="farm-watchdog") if bridge else None
        reactor = asyncio.create_task(reaction_worker(), name="farm-reactor")

        try:
            await stop_event.wait()
        finally:
            active_tasks = [t for t in (saver, watchdog, reactor) if t is not None]
            for t in active_tasks:
                t.cancel()
            for t in active_tasks:
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass

    finally:
        log.info("Останавливаю ферму...")
        for acc in accounts:
            try:
                await acc.stop()
            except Exception:
                log.exception("stop err %s", acc.name)
        if bridge:
            try:
                await bridge.stop()
            except Exception:
                pass
        await save_json(STATE_FILE, state.to_dict())
        await save_json(STATS_FILE, FARM_STATS)
        log.info("Ферма остановлена.")


# ═══════════════════════════════════════════════════════════════
#                    ENTRYPOINT
# ═══════════════════════════════════════════════════════════════

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Telegram userbot farm v5.1")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--check-only", action="store_true")
    p.add_argument("--test-bridge", action="store_true",
                   help="Проверить только DeepSeek bridge и выйти")
    p.add_argument("--donor-info", action="store_true",
                   help="Показать статистику донора и выйти")
    p.add_argument("--no-llm", action="store_true",
                   help="Работать без DeepSeek — репост текстов/медиа из донора")
    return p.parse_args()


async def _check_only() -> None:
    ok, report = await check_telegram_reachable(timeout=5.0)
    print(report)
    print("\nИТОГ:", "✅ OK" if ok else "❌ FAIL")


async def _test_bridge() -> None:
    log.info("Проверка DeepSeek bridge (главный процесс)...")
    bridge = DeepSeekBridge()
    try:
        await bridge.start()
        log.info("→ Отправляю тестовый промпт...")
        t = time.time()
        text = await bridge.ask("Ответь одним словом: ok", new_conversation=True)
        log.info("✅ Ответ за %.1fs: %r", time.time() - t, text[:200])
    finally:
        await bridge.stop()


async def _donor_info() -> None:
    donor = await DonorCorpus.load(DONOR_MESSAGES)
    print(f"messages: {len(donor.messages)}")
    print(f"texts: {len(donor.texts)}")
    print(f"qa_pairs: {len(donor.qa_pairs)}")
    print(f"fragments: {len(donor.fragments)}")
    for k, v in donor.media_by_kind.items():
        print(f"  {k}: {len(v)}")
    print("\nПримеры текстов:")
    for t in donor.sample_texts(5):
        print(" —", t[:100])


def main() -> int:
    args = parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if hasattr(sys.stderr, "reconfigure"):
        try:
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(name)-12s | %(message)s",
        stream=sys.stdout,
    )
    if args.debug:
        logging.getLogger("pyrogram").setLevel(logging.DEBUG)
    else:
        logging.getLogger("pyrogram").setLevel(logging.WARNING)

    if args.check_only:
        asyncio.run(_check_only()); return 0
    if args.test_bridge:
        asyncio.run(_test_bridge()); return 0
    if args.donor_info:
        asyncio.run(_donor_info()); return 0

    if args.no_llm:
        # загрузим конфиг и выставим флаг
        try:
            cfg = json.loads((ROOT / "farm_config.json").read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        cfg["no_llm"] = True
        (ROOT / "farm_config.json").write_text(
            json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    acquire_lock()
    try:
        asyncio.run(run_farm())
    except KeyboardInterrupt:
        log.info("Прервано")
    finally:
        release_lock()
    return 0


if __name__ == "__main__":
    sys.exit(main())