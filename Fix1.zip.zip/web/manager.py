# web/manager.py
from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional
from pyrogram import Client
from . import db

log = logging.getLogger("web.manager")
ROOT = db.ROOT
SESSIONS_DIR = ROOT / "sessions"
SESSIONS_DIR.mkdir(exist_ok=True)


def parse_proxy(proxy_str: Optional[str]) -> Optional[Dict[str, Any]]:
    """
    Парсит прокси из различных форматов в словарь для Pyrogram:
    1. socks5://user:pass@host:port или http://host:port
    2. host:port:user:pass
    3. host:port
    4. JSON: {"scheme": "socks5", "hostname": "...", "port": 1080, ...}
    """
    if not proxy_str or not proxy_str.strip():
        return None
    s = proxy_str.strip()

    # 1. JSON
    if s.startswith("{") and s.endswith("}"):
        try:
            d = json.loads(s)
            if isinstance(d, dict) and "hostname" in d and "port" in d:
                d["port"] = int(d["port"])
                d.setdefault("scheme", "socks5")
                return d
        except Exception:
            pass

    # 2. URL scheme: socks5://user:pass@host:port
    if "://" in s:
        try:
            u = urllib.parse.urlparse(s)
            scheme = u.scheme.lower()
            if scheme in ("socks5", "socks4", "http", "https"):
                p: Dict[str, Any] = {
                    "scheme": scheme if scheme != "https" else "http",
                    "hostname": u.hostname,
                    "port": int(u.port or (1080 if "socks" in scheme else 8080)),
                }
                if u.username:
                    p["username"] = urllib.parse.unquote(u.username)
                if u.password:
                    p["password"] = urllib.parse.unquote(u.password)
                return p
        except Exception:
            pass

    # 3. host:port:user:pass или host:port
    parts = s.split(":")
    if len(parts) == 4:
        host, port, user, pwd = parts
        if port.strip().isdigit():
            return {
                "scheme": "socks5",
                "hostname": host.strip(),
                "port": int(port.strip()),
                "username": user.strip(),
                "password": pwd.strip(),
            }
    elif len(parts) == 2 and parts[1].strip().isdigit():
        host, port = parts
        return {
            "scheme": "socks5",
            "hostname": host.strip(),
            "port": int(port.strip()),
        }

    # 4. Fallback через eval
    try:
        d = eval(s)
        if isinstance(d, dict) and "hostname" in d and "port" in d:
            d["port"] = int(d["port"])
            return d
    except Exception:
        pass

    return None


async def test_proxy_connection(proxy_val: str | Dict[str, Any]) -> Dict[str, Any]:
    """Проверяет доступность TCP-сокета прокси-сервера и замеряет задержку."""
    parsed = parse_proxy(proxy_val) if isinstance(proxy_val, str) else proxy_val
    if not parsed or not parsed.get("hostname") or not parsed.get("port"):
        return {"ok": False, "error": "Неверный формат строки прокси"}

    host = parsed["hostname"]
    port = int(parsed["port"])
    t0 = time.time()
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=6.0,
        )
        latency_ms = round((time.time() - t0) * 1000, 1)
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        return {
            "ok": True,
            "host": host,
            "port": port,
            "scheme": parsed.get("scheme", "socks5"),
            "latency_ms": latency_ms,
        }
    except Exception as e:
        return {"ok": False, "host": host, "port": port, "error": str(e)}


class AccountManager:
    """Держит открытые Pyrogram-клиенты, переиспользует между задачами."""

    def __init__(self) -> None:
        self._clients: Dict[str, Client] = {}
        self._lock = asyncio.Lock()

    async def get_client(self, name: str) -> Client:
        async with self._lock:
            if name in self._clients and self._clients[name].is_connected:
                return self._clients[name]

            acc = await db.get_account(name)
            if not acc:
                raise RuntimeError(f"Аккаунт {name} не найден в БД")

            kwargs: Dict[str, Any] = {
                "name": name,
                "api_id": int(acc["api_id"]),
                "api_hash": str(acc["api_hash"]),
                "workdir": str(SESSIONS_DIR),
                "phone_number": acc.get("phone"),
            }

            if acc.get("proxy"):
                parsed_proxy = parse_proxy(acc["proxy"])
                if parsed_proxy:
                    kwargs["proxy"] = parsed_proxy
                    log.info("Клиент %s подключается через прокси %s:%s", name, parsed_proxy["hostname"], parsed_proxy["port"])
                else:
                    log.warning("Не удалось распарсить прокси для %s: %s", name, acc["proxy"])

            client = Client(**kwargs)
            await client.start()
            self._clients[name] = client
            return client

    async def close(self, name: Optional[str] = None) -> None:
        async with self._lock:
            names = [name] if name else list(self._clients.keys())
            for n in names:
                c = self._clients.pop(n, None)
                if c:
                    try:
                        await c.stop()
                    except Exception:
                        log.exception("Ошибка при остановке клиента %s", n)

    async def list_active(self) -> List[str]:
        return list(self._clients.keys())

    async def scan_sessions_dir(self) -> List[dict]:
        """
        Найти .session-файлы в папке sessions/ и автоматически зарегистрировать
        аккаунты в БД, используя credentials из farm_config.json.
        Возвращает список dict: {name, source, status}.
        """
        results: List[dict] = []

        # Загружаем farm_config.json для автоматического подтягивания credentials
        cfg_accounts: Dict[str, dict] = {}
        cfg_path = ROOT / "farm_config.json"
        if cfg_path.exists():
            try:
                raw = json.loads(cfg_path.read_text(encoding="utf-8"))
                for acc in raw.get("accounts", []):
                    if acc.get("name"):
                        cfg_accounts[acc["name"]] = acc
            except Exception as e:
                log.warning("scan: не удалось прочитать farm_config.json: %s", e)

        for p in sorted(SESSIONS_DIR.glob("*.session")):
            name = p.stem
            await db.add_session(name, str(p))

            cfg_acc = cfg_accounts.get(name)
            if cfg_acc and cfg_acc.get("api_id") and cfg_acc.get("api_hash"):
                try:
                    await db.upsert_account(
                        name,
                        api_id=int(cfg_acc["api_id"]),
                        api_hash=str(cfg_acc["api_hash"]),
                        phone=cfg_acc.get("phone", ""),
                        proxy=cfg_acc.get("proxy", ""),
                        persona=cfg_acc.get("persona", ""),
                        reply_probability=float(cfg_acc.get("reply_probability", 0.8)),
                        media_bias=json.dumps(cfg_acc.get("media_bias", {})) if isinstance(cfg_acc.get("media_bias"), dict) else cfg_acc.get("media_bias", ""),
                        enabled=1,
                    )
                    results.append({"name": name, "source": "farm_config.json", "status": "imported"})
                    log.info("scan: аккаунт %s авто-импортирован из farm_config.json", name)
                except Exception as e:
                    log.exception("scan: ошибка авто-импорта %s", name)
                    results.append({"name": name, "source": "farm_config.json", "status": f"error: {e}"})
            else:
                # Сессия найдена, но credentials не найдены — требуется ручной импорт
                results.append({"name": name, "source": "sessions/", "status": "found (нужен ручной импорт)"})

        return results


manager = AccountManager()


async def import_session_file(
    filename: str,
    api_id: int,
    api_hash: str,
    phone: Optional[str] = None,
    proxy: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Принимает имя файла из SESSIONS_DIR, проверяет через Pyrogram,
    сохраняет в БД вместе с привязанным прокси. Возвращает инфу об аккаунте.
    """
    name = Path(filename).stem
    path = SESSIONS_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"{path} не найден")

    kwargs: Dict[str, Any] = {
        "name": name,
        "api_id": api_id,
        "api_hash": api_hash,
        "workdir": str(SESSIONS_DIR),
        "phone_number": phone,
    }

    if proxy and proxy.strip():
        parsed_proxy = parse_proxy(proxy)
        if parsed_proxy:
            kwargs["proxy"] = parsed_proxy

    client = Client(**kwargs)
    await client.start()
    try:
        me = await client.get_me()
        info = {
            "name": name,
            "tg_id": me.id,
            "username": me.username,
            "first_name": me.first_name,
            "proxy": proxy.strip() if proxy else "",
        }
        await db.upsert_account(
            name,
            phone=phone or "",
            api_id=api_id,
            api_hash=api_hash,
            proxy=proxy.strip() if proxy else "",
            enabled=1,
        )
        return info
    finally:
        await client.stop()


async def update_account_proxy(name: str, proxy: str) -> Dict[str, Any]:
    """Обновляет прокси для аккаунта, пересбрасывает соединение и тестирует сокет."""
    await manager.close(name)
    proxy_clean = proxy.strip() if proxy else ""
    await db.upsert_account(name, proxy=proxy_clean)

    if proxy_clean:
        test_res = await test_proxy_connection(proxy_clean)
        return {"ok": True, "proxy": proxy_clean, "test": test_res}
    return {"ok": True, "proxy": "", "test": {"ok": True, "message": "Прокси удалён"}}
