# web/deepseek.py
from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("web.deepseek")

ROOT = Path(__file__).resolve().parent.parent
BRIDGE_DIR = ROOT / "vendor" / "Deepseek-API"
if BRIDGE_DIR.exists():
    sys.path.insert(0, str(BRIDGE_DIR))

try:
    from deepseek import DeepSeekClient  # noqa: E402
except ImportError:
    DeepSeekClient = None  # type: ignore

DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "default")
DEEPSEEK_THINKING = os.getenv("DEEPSEEK_THINKING", "false").lower() == "true"
DEEPSEEK_SEARCH = os.getenv("DEEPSEEK_SEARCH", "false").lower() == "true"


class AI:
    def __init__(self) -> None:
        self._client: Any = None
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if DeepSeekClient is None:
            log.warning("DeepSeek bridge недоступен (DeepSeekClient не импортирован)")
            return
        if self._client is None:
            self._client = await asyncio.to_thread(DeepSeekClient, None, False)
            log.info("DeepSeek client инициализирован")

    async def ask(self, prompt: str, new_conversation: bool = False) -> str:
        async with self._lock:
            if self._client is None:
                await self.start()
            if self._client is None:
                return "Ошибка: DeepSeek bridge не запущен или недоступен"

            reply = await asyncio.to_thread(
                self._client.chat,
                prompt,
                model=DEEPSEEK_MODEL,
                thinking=DEEPSEEK_THINKING,
                search=DEEPSEEK_SEARCH,
            )
            text = getattr(reply, "text", str(reply))
            return text.strip()

    async def stop(self) -> None:
        if self._client is not None:
            try:
                await asyncio.to_thread(self._client.close)
            except Exception:
                pass
            self._client = None


ai = AI()
