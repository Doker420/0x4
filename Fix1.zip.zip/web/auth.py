# web/auth.py
from __future__ import annotations

import secrets
from typing import Optional, Dict, Any
from fastapi import Cookie, HTTPException, status
from itsdangerous import BadSignature, URLSafeSerializer
import bcrypt
from . import db

SECRET_FILE = db.ROOT / "data" / "web.secret"


def _secret() -> str:
    if not SECRET_FILE.exists():
        SECRET_FILE.parent.mkdir(exist_ok=True)
        SECRET_FILE.write_text(secrets.token_hex(32), encoding="utf-8")
    return SECRET_FILE.read_text(encoding="utf-8").strip()


_serializer = URLSafeSerializer(_secret(), salt="web-auth")


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except Exception:
        return False


def make_token(owner_id: int, username: str) -> str:
    return _serializer.dumps({"id": owner_id, "u": username})


def read_token(token: str) -> Optional[Dict[str, Any]]:
    try:
        data = _serializer.loads(token)
        return dict(data) if isinstance(data, dict) else None
    except (BadSignature, Exception):
        return None


def require_owner(token: Optional[str]) -> Dict[str, Any]:
    if not token:
        raise HTTPException(
            status_code=status.HTTP_303_SEE_OTHER,
            headers={"Location": "/login"},
        )
    data = read_token(token)
    if not data:
        raise HTTPException(
            status_code=status.HTTP_303_SEE_OTHER,
            headers={"Location": "/login"},
        )
    return data
