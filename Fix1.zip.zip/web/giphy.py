# web/giphy.py
from __future__ import annotations

import os
import random
from typing import Any, List, Optional
import httpx
from . import db

GIPHY_KEY = os.getenv("GIPHY_KEY", "")
TENOR_KEY = os.getenv("TENOR_KEY", "")


async def _get_keys() -> tuple[str, str]:
    gk = GIPHY_KEY or await db.get_setting("giphy_key", "")
    tk = TENOR_KEY or await db.get_setting("tenor_key", "")
    return gk, tk


async def search_gif(query: str, limit: int = 20) -> List[str]:
    giphy_key, tenor_key = await _get_keys()
    urls: List[str] = []

    if giphy_key:
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get(
                    "https://api.giphy.com/v1/gifs/search",
                    params={"api_key": giphy_key, "q": query, "limit": limit, "rating": "pg-13"},
                )
                if r.status_code == 200:
                    for item in r.json().get("data", []):
                        url = (
                            item.get("images", {}).get("downsized", {}).get("url")
                            or item.get("images", {}).get("original", {}).get("url")
                        )
                        if url:
                            urls.append(url)
        except Exception:
            pass

    if not urls and tenor_key:
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get(
                    "https://tenor.googleapis.com/v2/search",
                    params={"key": tenor_key, "q": query, "limit": limit},
                )
                if r.status_code == 200:
                    for item in r.json().get("results", []):
                        url = item.get("media_formats", {}).get("gif", {}).get("url")
                        if url:
                            urls.append(url)
        except Exception:
            pass

    return urls


async def random_gif(query: str = "") -> Optional[str]:
    urls = await search_gif(query or "funny", limit=25)
    return random.choice(urls) if urls else None


async def search_meme_photo(query: str = "funny meme", limit: int = 20) -> List[str]:
    """imgflip API / meme-api.com"""
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get("https://meme-api.com/gimme/wholesomememes")
            if r.status_code == 200:
                data = r.json()
                if "url" in data:
                    return [data["url"]]
    except Exception:
        pass
    return []


async def random_photo() -> Optional[str]:
    """Lorem Picsum — стабильно работает без ключа."""
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get("https://picsum.photos/800/600", follow_redirects=False)
            if r.status_code in (301, 302):
                return r.headers.get("location")
    except Exception:
        pass
    return None
