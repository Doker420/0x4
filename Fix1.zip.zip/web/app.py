# web/app.py
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import Cookie, FastAPI, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from . import auth, db, giphy, manager, mass_actions, tasks
from .deepseek import ai

log = logging.getLogger("web")
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="Farm Panel")


# ─── Регистрация обработчиков задач ───
@tasks.register("mass_join")
async def _h_mass_join(payload: dict) -> dict:
    return await mass_actions.mass_join(
        payload["accounts"], payload["target"], tuple(payload.get("delay", [5, 20]))
    )


@tasks.register("mass_bio")
async def _h_mass_bio(payload: dict) -> dict:
    return await mass_actions.mass_set_bio(payload["accounts"], payload["bio"])


@tasks.register("mass_avatar")
async def _h_mass_avatar(payload: dict) -> dict:
    return await mass_actions.mass_set_avatar(payload["accounts"], payload["photos"])


@tasks.register("create_group")
async def _h_create_group(payload: dict) -> dict:
    return await mass_actions.create_group(
        payload["account"], payload["title"], payload.get("members")
    )


@tasks.register("create_channel")
async def _h_create_channel(payload: dict) -> dict:
    return await mass_actions.create_channel(
        payload["account"], payload["title"], payload.get("about", "")
    )


@tasks.register("parse_users")
async def _h_parse_users(payload: dict) -> dict:
    users = await mass_actions.parse_users(
        payload["reader"], int(payload["chat_id"]), int(payload.get("limit", 1000))
    )
    out_path = db.ROOT / "data" / f"parsed_{payload['chat_id']}.json"
    out_path.write_text(json.dumps(users, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"count": len(users), "file": str(out_path.relative_to(db.ROOT))}


@tasks.register("comment_post")
async def _h_comment_post(payload: dict) -> dict:
    return await mass_actions.comment_post(
        payload["account"], payload["url"], payload["comment"]
    )


@tasks.register("history_fetch")
async def _h_history_fetch(payload: dict) -> dict:
    msgs = await mass_actions.fetch_history(
        payload["reader"], payload["chat"], int(payload.get("limit", 500))
    )
    out_path = db.ROOT / "data" / f"history_{str(payload['chat']).replace('/', '_')}.json"
    out_path.write_text(json.dumps(msgs, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"count": len(msgs), "file": str(out_path.relative_to(db.ROOT))}


FARM_PROCESS: Optional[asyncio.subprocess.Process] = None
FARM_LOG_FILE = db.ROOT / "data" / "farm.log"


@tasks.register("start_chatfarm")
async def _h_start_chatfarm(payload: dict) -> dict:
    """Запускает farm.py как подпроцесс с переопределенными параметрами."""
    global FARM_PROCESS
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["FARM_OVERRIDE_TARGET"] = str(payload.get("target_id", 0))
    env["FARM_OVERRIDE_MIN_DELAY"] = str(payload.get("min_delay", 5))
    env["FARM_OVERRIDE_MAX_DELAY"] = str(payload.get("max_delay", 45))

    FARM_LOG_FILE.parent.mkdir(exist_ok=True)
    FARM_LOG_FILE.write_text("", encoding="utf-8")

    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-u",
        str(db.ROOT / "farm.py"),
        "--debug",
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    FARM_PROCESS = proc
    log.info("farm.py запущен (PID=%s)", proc.pid)

    out_lines: List[str] = []
    try:
        if proc.stdout:
            while True:
                line = await proc.stdout.readline()
                if not line:
                    break
                text = line.decode("utf-8", "replace").rstrip()
                out_lines.append(text)
                log.info("[farm.py] %s", text)
                with open(FARM_LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
                    f.write(text + "\n")
                if len(out_lines) > 1000:
                    out_lines.pop(0)

        await proc.wait()
    finally:
        FARM_PROCESS = None
        lock_file = db.ROOT / "data" / "farm.lock"
        if lock_file.exists():
            try:
                lock_file.unlink(missing_ok=True)
            except Exception:
                pass

    return {"exit_code": proc.returncode, "tail": out_lines[-50:]}


# ─── Startup / Shutdown ───
@app.on_event("startup")
async def _startup() -> None:
    await db.init_db()
    await tasks.runner.start()
    try:
        await ai.start()
    except Exception:
        log.exception("DeepSeek AI не подключился — функции генерации будут работать в автономном режиме")


@app.on_event("shutdown")
async def _shutdown() -> None:
    await tasks.runner.stop()
    await manager.manager.close()
    await ai.stop()


# ─── Auth helpers ───
def _current_owner(web_auth: Optional[str]) -> dict:
    return auth.require_owner(web_auth)


# ─── Роуты страниц ───
@app.get("/", response_class=HTMLResponse)
async def root(web_auth: Optional[str] = Cookie(default=None)):
    if not web_auth:
        return RedirectResponse("/login")
    return RedirectResponse("/dashboard")


@app.get("/register", response_class=HTMLResponse)
async def register_form(request: Request):
    if await db.owner_exists():
        return RedirectResponse("/login")
    return templates.TemplateResponse("register.html", {"request": request})


@app.post("/register")
async def register_post(username: str = Form(...), password: str = Form(...)):
    if await db.owner_exists():
        return RedirectResponse("/login", status_code=303)
    if len(password) < 6:
        raise HTTPException(400, "Пароль минимум 6 символов")
    await db.create_owner(username, auth.hash_password(password))
    return RedirectResponse("/login", status_code=303)


@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    has_owner = await db.owner_exists()
    return templates.TemplateResponse("login.html", {"request": request, "has_owner": has_owner})


@app.post("/login")
async def login_post(username: str = Form(...), password: str = Form(...)):
    owner = await db.get_owner(username)
    if not owner or not auth.verify_password(password, owner["password_hash"]):
        raise HTTPException(401, "Неверный логин или пароль")
    token = auth.make_token(owner["id"], owner["username"])
    resp = RedirectResponse("/dashboard", status_code=303)
    resp.set_cookie("web_auth", token, httponly=True, samesite="lax", max_age=30 * 24 * 3600)
    return resp


@app.get("/logout")
async def logout():
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie("web_auth")
    return resp


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    tasks_list = await db.list_tasks(20)
    return templates.TemplateResponse(
        "dashboard.html",
        {"request": request, "accounts": accounts, "tasks": tasks_list},
    )


# ─── Accounts ───
@app.get("/accounts", response_class=HTMLResponse)
async def accounts_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    sessions = await db.list_sessions()
    return templates.TemplateResponse(
        "accounts.html",
        {"request": request, "accounts": accounts, "sessions": sessions},
    )


@app.post("/api/accounts/scan")
async def api_scan_sessions(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    found = await manager.manager.scan_sessions_dir()
    return {"sessions": found}


@app.post("/api/accounts/import")
async def api_import_session(
    session_name: str = Form(...),
    api_id: int = Form(...),
    api_hash: str = Form(...),
    phone: str = Form(default=""),
    proxy: str = Form(default=""),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    try:
        info = await manager.import_session_file(
            f"{session_name}.session",
            api_id,
            api_hash,
            phone=phone or None,
            proxy=proxy or None,
        )
        return {"ok": True, "info": info}
    except FileNotFoundError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=404)
    except Exception as e:
        log.exception("Ошибка импорта сессии %s", session_name)
        return JSONResponse({"ok": False, "error": str(e)}, status_code=200)


@app.post("/api/accounts/save")
async def api_save_account(
    name: str = Form(...),
    api_id: int = Form(...),
    api_hash: str = Form(...),
    phone: str = Form(default=""),
    proxy: str = Form(default=""),
    persona: str = Form(default=""),
    reply_probability: float = Form(default=0.8),
    media_bias: str = Form(default='{"text":0.6,"sticker":0.2,"gif":0.1,"photo":0.05,"voice":0.05}'),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    await db.upsert_account(
        name,
        api_id=api_id,
        api_hash=api_hash,
        phone=phone,
        proxy=proxy.strip(),
        persona=persona,
        reply_probability=reply_probability,
        media_bias=media_bias,
    )
    return {"ok": True}


@app.post("/api/accounts/set-proxy")
async def api_set_proxy(
    name: str = Form(...),
    proxy: str = Form(default=""),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    res = await manager.update_account_proxy(name, proxy)
    return res


@app.post("/api/accounts/test-proxy")
async def api_test_proxy(
    proxy: str = Form(...),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    res = await manager.test_proxy_connection(proxy)
    return res


@app.post("/api/accounts/delete")
async def api_delete_account(name: str = Form(...), web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    await manager.manager.close(name)
    await db.delete_account(name)
    return {"ok": True}


# ─── Chat farm ───
@app.get("/chatfarm", response_class=HTMLResponse)
async def chatfarm_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    targets = await db.list_targets()
    return templates.TemplateResponse(
        "chatfarm.html",
        {"request": request, "accounts": accounts, "targets": targets},
    )


@app.post("/api/chatfarm/start")
async def api_chatfarm_start(
    accounts: str = Form(...),
    target_id: int = Form(...),
    min_delay: int = Form(default=5),
    max_delay: int = Form(default=45),
    qa_probability: float = Form(default=0.35),
    clone_probability: float = Form(default=0.45),
    reaction_probability: float = Form(default=0.35),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    acc_list = [a.strip() for a in accounts.split(",") if a.strip()]
    task_id = await tasks.runner.submit(
        "start_chatfarm",
        {
            "accounts": acc_list,
            "target_id": target_id,
            "min_delay": min_delay,
            "max_delay": max_delay,
            "qa_probability": qa_probability,
            "clone_probability": clone_probability,
            "reaction_probability": reaction_probability,
        },
    )
    return {"ok": True, "task_id": task_id}


@app.get("/api/chatfarm/status")
async def api_chatfarm_status(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    is_running = FARM_PROCESS is not None and FARM_PROCESS.returncode is None
    return {
        "running": is_running,
        "pid": FARM_PROCESS.pid if is_running else None,
    }


@app.get("/api/chatfarm/logs")
async def api_chatfarm_logs(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    if not FARM_LOG_FILE.exists():
        return {"logs": ["Лог-файл farm.log пока пуст. Запустите ферму."]}
    try:
        lines = FARM_LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        return {"logs": lines[-120:] if lines else ["Ожидание вывода..."]}
    except Exception as e:
        return {"logs": [f"Ошибка чтения лога: {e}"]}


@app.post("/api/chatfarm/stop")
async def api_chatfarm_stop(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    global FARM_PROCESS
    stopped = False
    if FARM_PROCESS is not None and FARM_PROCESS.returncode is None:
        try:
            FARM_PROCESS.terminate()
            try:
                await asyncio.wait_for(FARM_PROCESS.wait(), timeout=3.0)
            except asyncio.TimeoutError:
                FARM_PROCESS.kill()
            stopped = True
        except Exception as e:
            log.exception("Ошибка при остановке farm.py: %s", e)
        finally:
            FARM_PROCESS = None

    lock_file = db.ROOT / "data" / "farm.lock"
    if lock_file.exists():
        try:
            lock_file.unlink(missing_ok=True)
        except Exception:
            pass

    return {"ok": True, "stopped": stopped}


# ─── Comments ───
@app.get("/comments", response_class=HTMLResponse)
async def comments_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    return templates.TemplateResponse("comments.html", {"request": request, "accounts": accounts})


@app.post("/api/comments/generate")
async def api_generate_comment(
    url: str = Form(...),
    topic: str = Form(default=""),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    prompt = (
        f"Напиши живой развёрнутый комментарий (2–4 предложения) к посту по ссылке {url}. "
        f"Тема/настроение: {topic or 'нейтрально-позитивное'}. "
        f"Без мата, без оскорблений, разговорно, с эмодзи уместно."
    )
    text = await ai.ask(prompt, new_conversation=True)
    return {"text": text}


@app.post("/api/comments/post")
async def api_post_comment(
    account: str = Form(...),
    url: str = Form(...),
    comment: str = Form(...),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    task_id = await tasks.runner.submit(
        "comment_post",
        {
            "account": account,
            "url": url,
            "comment": comment,
        },
    )
    return {"ok": True, "task_id": task_id}


# ─── Mass actions ───
@app.get("/mass", response_class=HTMLResponse)
async def mass_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    return templates.TemplateResponse("mass.html", {"request": request, "accounts": accounts})


@app.post("/api/mass/join")
async def api_mass_join(
    accounts: str = Form(...),
    target: str = Form(...),
    min_delay: float = Form(default=5),
    max_delay: float = Form(default=20),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    accs = [a.strip() for a in accounts.split(",") if a.strip()]
    task_id = await tasks.runner.submit(
        "mass_join",
        {
            "accounts": accs,
            "target": target,
            "delay": [min_delay, max_delay],
        },
    )
    return {"ok": True, "task_id": task_id}


@app.post("/api/mass/bio")
async def api_mass_bio(
    accounts: str = Form(...),
    bio: str = Form(...),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    accs = [a.strip() for a in accounts.split(",") if a.strip()]
    task_id = await tasks.runner.submit("mass_bio", {"accounts": accs, "bio": bio})
    return {"ok": True, "task_id": task_id}


@app.post("/api/mass/create-group")
async def api_create_group(
    account: str = Form(...),
    title: str = Form(...),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    task_id = await tasks.runner.submit("create_group", {"account": account, "title": title})
    return {"ok": True, "task_id": task_id}


# ─── Parser ───
@app.get("/parser", response_class=HTMLResponse)
async def parser_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    accounts = await db.list_accounts()
    return templates.TemplateResponse("parser.html", {"request": request, "accounts": accounts})


@app.post("/api/parser/users")
async def api_parse_users(
    reader: str = Form(...),
    chat_id: int = Form(...),
    limit: int = Form(default=1000),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    task_id = await tasks.runner.submit(
        "parse_users",
        {
            "reader": reader,
            "chat_id": chat_id,
            "limit": limit,
        },
    )
    return {"ok": True, "task_id": task_id}


# ─── GIF / Photo ───
@app.get("/api/gif/search")
async def api_gif_search(q: str, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    urls = await giphy.search_gif(q, 20)
    return {"urls": urls}


@app.get("/api/photo/random")
async def api_photo_random(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    url = await giphy.random_photo()
    return {"url": url}


# ─── Tasks & Settings ───
@app.get("/tasks", response_class=HTMLResponse)
async def tasks_page(request: Request, web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    items = await db.list_tasks(100)
    return templates.TemplateResponse("settings.html", {"request": request, "tasks": items})


@app.get("/api/tasks/list")
async def api_tasks_list(web_auth: Optional[str] = Cookie(default=None)):
    _current_owner(web_auth)
    return {"tasks": await db.list_tasks(100)}


@app.post("/api/settings/save")
async def api_settings_save(
    giphy_key: str = Form(default=""),
    tenor_key: str = Form(default=""),
    web_auth: Optional[str] = Cookie(default=None),
):
    _current_owner(web_auth)
    await db.set_setting("giphy_key", giphy_key)
    await db.set_setting("tenor_key", tenor_key)
    return {"ok": True}
